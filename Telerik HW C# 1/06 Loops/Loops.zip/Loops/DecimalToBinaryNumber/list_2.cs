﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DecimalToBinaryNumber
{
    class list<T>
    {
        internal void Add(long p)
        {
            throw new NotImplementedException();
        }

        public int Max { get; set; }
    }
}
