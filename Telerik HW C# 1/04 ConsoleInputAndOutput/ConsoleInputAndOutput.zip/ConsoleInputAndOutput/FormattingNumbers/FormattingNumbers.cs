﻿using System;

class FormattingNumbers
{
    static void Main()
    {
        Console.WriteLine("Please enter a");
        double a = double.Parse(Console.ReadLine());
        Console.WriteLine("Please enter b");
        double b = double.Parse(Console.ReadLine());
        Console.WriteLine("Please enter c");
        double c = double.Parse(Console.ReadLine());


        Console.WriteLine(");
    }
}

