﻿//Create a console application that prints the current date and time. Find out how in Internet.

using System;

class CurrentDateAndTime
{
    static void Main()
    {
        Console.WriteLine(DateTime.Now);
    }
}

