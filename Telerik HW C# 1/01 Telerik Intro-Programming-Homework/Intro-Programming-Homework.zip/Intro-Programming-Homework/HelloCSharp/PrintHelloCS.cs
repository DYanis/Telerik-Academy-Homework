﻿//Create, compile and run a “Hello C#” console application.
//Ensure you have named the application well (e.g. “”HelloCSharp”).

using System;

class HelloCSharp
{
    static void Main()
    {
        Console.Write("Hello C#");
    }
}

