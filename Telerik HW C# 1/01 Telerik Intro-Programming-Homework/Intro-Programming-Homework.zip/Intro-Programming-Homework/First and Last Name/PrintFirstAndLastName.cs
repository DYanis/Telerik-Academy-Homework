﻿//Create console application that prints your first and last name, each at a separate line.

using System;

class FirstandLastName
{
    static void Main()
    {
        Console.WriteLine("User");
        Console.WriteLine("User");
    }
}

