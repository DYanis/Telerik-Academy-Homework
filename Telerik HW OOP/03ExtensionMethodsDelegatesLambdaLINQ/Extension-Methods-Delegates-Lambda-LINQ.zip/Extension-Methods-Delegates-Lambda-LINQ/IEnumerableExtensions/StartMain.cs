﻿namespace IEnumerableExtensions
{
    using System;
    using System.Linq;

    class StartMain
    {
        static void Main()
        {
            int[] arr = { 32, 4231, 3, 534, 32 };
            Console.WriteLine(arr.Average());
        }
    }
}
