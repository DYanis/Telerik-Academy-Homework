﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Path
{
    class Path
    {
        static void Main(string[] args)
        {
        }
    }
}
