﻿namespace BankAccounts.AccountInterfaces
{
    using System;

    interface ILoanAccountAndMortgageAccount
    {
        void DepositMoney(decimal money);
    }
}