﻿namespace BankAccounts
{
    using System;

    public enum Customers
    {
        individual, company
    }
}
