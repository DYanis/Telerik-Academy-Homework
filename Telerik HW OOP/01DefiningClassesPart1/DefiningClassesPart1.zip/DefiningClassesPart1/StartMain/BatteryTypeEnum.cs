﻿namespace StartMain
{
    public enum BatteryTypeEnum
    {
        LiIon, NiMH, NiCd
    }
}
