﻿namespace StartMain
{
    using System;
    using System.Linq;

    class Battery
    {
        // model, hours idle and hours talk

        public string model;
        public string hoursIdle;
        public string hoursTalk;


    }
}
