﻿namespace StartMain
{
    using System;
    using System.Linq;

    class Display
    {
        // size and number of colors
        public double size;
        public long numberOfColors;
    }
}
