﻿namespace PersonClass
{
    using System;

    class Start
    {
        static void Main()
        {
        }
    }
}
