﻿namespace Problem_01_Student_class
{
    using System;

    public enum Speciality
    {
        mathematics,
        informathics,
        computarScience
    }
}
