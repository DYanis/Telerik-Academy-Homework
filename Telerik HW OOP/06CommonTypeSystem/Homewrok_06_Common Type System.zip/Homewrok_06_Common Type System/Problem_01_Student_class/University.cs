﻿namespace Problem_01_Student_class
{
    using System;

    public enum University
    {
        SofiaUniversity,
        BostonUniversity,
        Harvard
    }

}
