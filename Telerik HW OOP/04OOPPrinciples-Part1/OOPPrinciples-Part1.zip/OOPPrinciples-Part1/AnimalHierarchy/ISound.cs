﻿namespace AnimalHierarchy
{
    using System;
    using System.Linq;

    public interface ISound
    {
        void MakeSound();
    }
}
