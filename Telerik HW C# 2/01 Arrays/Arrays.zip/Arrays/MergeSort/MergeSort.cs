﻿using System;
using System.Linq;

class MergeSort
{
    static void Main()
    {
    }
}

