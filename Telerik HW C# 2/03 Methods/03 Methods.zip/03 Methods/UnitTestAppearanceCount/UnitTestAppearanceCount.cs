﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestAppearanceCount
{
    [TestClass]
    public class UnitTestAppearanceCount
    {
        [TestMethod]
        public void TestMethod1()
        {
            int[] arr = { 1, 32, 32, 2, 1, 4, 51, 32, 51, 20 };
            int number = 32;

          
        }
    }
}
