var number = prompt('number?');
console.log(number);

if ( number % 5 === 0 && number % 7 === 0){
    console.log(true);
}
else{
    console.log(false);
}