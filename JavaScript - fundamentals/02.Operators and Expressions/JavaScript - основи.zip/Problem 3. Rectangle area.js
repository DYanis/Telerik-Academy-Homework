
var width = prompt('Please add width');
var height = prompt('Please add height');

console.log('Area: ' + width*height);