
var a = Number(prompt('a ?')),
    b = Number(prompt('b ?')),
    h = Number(prompt('h ?'));


console.log(((a+b)/2)*h);