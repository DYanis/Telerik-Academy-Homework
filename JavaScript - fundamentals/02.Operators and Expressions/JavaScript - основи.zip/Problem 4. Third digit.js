
var number = prompt('Please add a number');
var result = number[number.length - 3];
if(result === 7) {
    console.log(true);
}
else{
    console.log(false);
}